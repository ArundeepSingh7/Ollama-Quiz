"""
streamlit_app.py — Testing UI for QuizAI API
Run with: streamlit run streamlit_app.py

Make sure the FastAPI backend is running first:
  cd backend && python main.py
"""

import streamlit as st
import requests
import json
import time

# ── Config ───────────────────────────────────────────────────────────────────
API_URL = "http://localhost:8000"   # change if your backend is on a different host

st.set_page_config(
    page_title="QuizAI — Test Console",
    page_icon="🧠",
    layout="wide",
)

# ── Custom CSS ────────────────────────────────────────────────────────────────
st.markdown("""
<style>
    [data-testid="stAppViewContainer"] { background: #0f0f1a; }
    [data-testid="stSidebar"] { background: #13131f; }
    h1, h2, h3 { color: #e2e0f0 !important; }
    .stTextInput > div > div > input { background: #1a1a2a; color: #e2e0f0; border-color: #2a2836; }
    .api-status-ok { background: rgba(52,211,153,.1); border: 1px solid rgba(52,211,153,.3); 
                     border-radius: 8px; padding: 8px 16px; color: #34d399; font-weight: 600; }
    .api-status-err { background: rgba(248,113,113,.1); border: 1px solid rgba(248,113,113,.3); 
                      border-radius: 8px; padding: 8px 16px; color: #f87171; font-weight: 600; }
    .q-card { background: #1a1a2a; border: 1px solid #2a2836; border-radius: 12px; 
               padding: 1.2rem; margin-bottom: 1rem; }
    .q-correct { border-left: 3px solid #34d399 !important; }
    .q-wrong   { border-left: 3px solid #f87171 !important; }
    .score-box { background: linear-gradient(135deg, #7c5cfc, #5c3fcc); border-radius: 16px;
                 padding: 2rem; text-align: center; color: white; margin-bottom: 1.5rem; }
</style>
""", unsafe_allow_html=True)

# ── State ─────────────────────────────────────────────────────────────────────
if "quiz" not in st.session_state:
    st.session_state.quiz = None
if "answers" not in st.session_state:
    st.session_state.answers = {}
if "submitted" not in st.session_state:
    st.session_state.submitted = False


# ── Sidebar ───────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("## ⚙️ Settings")
    api_url = st.text_input("API URL", value=API_URL)

    st.markdown("---")
    st.markdown("### Quiz Config")
    num_questions = st.slider("Number of Questions", 3, 20, 5)
    question_type = st.selectbox(
        "Question Type",
        ["Multiple Choice", "True / False", "Short Answer", "Mixed"],
    )
    difficulty = st.selectbox("Difficulty", ["Easy", "Medium", "Hard"])

    st.markdown("---")
    # API Health
    if st.button("🔄 Check API Status", use_container_width=True):
        try:
            r = requests.get(f"{api_url}/health", timeout=5)
            data = r.json()
            if data.get("healthy"):
                st.markdown('<div class="api-status-ok">✅ API is online & model loaded</div>', unsafe_allow_html=True)
            else:
                st.markdown('<div class="api-status-err">⚠️ API online but model not ready yet</div>', unsafe_allow_html=True)
        except Exception as e:
            st.markdown(f'<div class="api-status-err">❌ Cannot reach API: {e}</div>', unsafe_allow_html=True)

    st.markdown("---")
    st.markdown("**API Endpoints**")
    st.code(f"{api_url}/docs", language=None)
    st.caption("Open the URL above to see interactive API docs (Swagger UI)")

    if st.button("🗑️ Reset Quiz", use_container_width=True):
        st.session_state.quiz = None
        st.session_state.answers = {}
        st.session_state.submitted = False
        st.rerun()


# ── Main Area ─────────────────────────────────────────────────────────────────
st.markdown("# 🧠 QuizAI — Test Console")
st.markdown("Upload a document → generate a quiz → take it interactively. Tests your backend API.")

tab_generate, tab_quiz, tab_raw_api = st.tabs(["📄 Generate Quiz", "📝 Take Quiz", "🔌 Raw API Test"])


# ── TAB 1: Generate ───────────────────────────────────────────────────────────
with tab_generate:
    st.markdown("### Upload a Document")
    uploaded_file = st.file_uploader(
        "PDF or Word file",
        type=["pdf", "doc", "docx"],
        label_visibility="collapsed",
    )

    if uploaded_file:
        st.success(f"📎 {uploaded_file.name} ({uploaded_file.size // 1024} KB)")

        col1, col2 = st.columns([2, 1])
        with col1:
            if st.button("✦ Generate Quiz", type="primary", use_container_width=True):
                with st.spinner("Extracting text from document..."):
                    # First, extract and preview text
                    try:
                        r = requests.post(
                            f"{api_url}/extract-text",
                            files={"file": (uploaded_file.name, uploaded_file.getvalue(), uploaded_file.type)},
                            timeout=30,
                        )
                        r.raise_for_status()
                        meta = r.json()
                        st.info(
                            f"📊 Document: **{meta['word_count']} words** | "
                            f"Max recommended questions: **{meta['max_recommended_questions']}**"
                        )
                    except Exception as e:
                        st.error(f"Could not read file: {e}")
                        st.stop()

                # Stream quiz generation
                st.markdown("#### 🤖 Generating (word by word)...")
                output_placeholder = st.empty()
                streamed = ""

                try:
                    with requests.post(
                        f"{api_url}/generate-quiz-stream",
                        files={"file": (uploaded_file.name, uploaded_file.getvalue(), uploaded_file.type)},
                        data={
                            "num_questions": num_questions,
                            "question_type": question_type,
                            "difficulty": difficulty,
                        },
                        stream=True,
                        timeout=300,
                    ) as resp:
                        resp.raise_for_status()
                        quiz_data = None

                        for line in resp.iter_lines():
                            if not line:
                                continue
                            line = line.decode("utf-8")
                            if not line.startswith("data: "):
                                continue
                            try:
                                event = json.loads(line[6:])
                            except json.JSONDecodeError:
                                continue

                            if event["type"] == "token":
                                streamed += event["token"]
                                output_placeholder.code(streamed[-2000:], language="json")  # show last 2000 chars

                            elif event["type"] == "done":
                                quiz_data = event["quiz"]
                                break

                            elif event["type"] == "error":
                                st.error(f"Generation error: {event['message']}")
                                st.stop()

                    if quiz_data:
                        st.session_state.quiz = quiz_data
                        st.session_state.answers = {}
                        st.session_state.submitted = False
                        output_placeholder.empty()
                        st.success(f"✅ Quiz generated: **{len(quiz_data['questions'])} questions** about *{quiz_data['title']}*")
                        st.info("👉 Switch to the **Take Quiz** tab to answer the questions!")
                    else:
                        st.error("Generation completed but no quiz was returned. Check the Raw API Test tab.")

                except requests.exceptions.ConnectionError:
                    st.error(f"Cannot connect to API at {api_url}. Is the backend running?")
                except Exception as e:
                    st.error(f"Error: {e}")

        with col2:
            if st.session_state.quiz:
                q = st.session_state.quiz
                st.metric("Questions", len(q["questions"]))
                st.metric("Title", q["title"][:30] + "..." if len(q.get("title","")) > 30 else q.get("title","—"))


# ── TAB 2: Take Quiz ──────────────────────────────────────────────────────────
with tab_quiz:
    if not st.session_state.quiz:
        st.info("Generate a quiz first from the **Generate Quiz** tab.")
    else:
        quiz = st.session_state.quiz
        questions = quiz["questions"]
        answers = st.session_state.answers
        submitted = st.session_state.submitted

        st.markdown(f"## {quiz['title']}")
        st.markdown(f"`{len(questions)} questions` · `{difficulty}` difficulty")
        st.progress(len(answers) / len(questions))

        if not submitted:
            for q in questions:
                st.markdown(f"---")
                type_label = {"mcq": "Multiple Choice", "tf": "True / False", "short": "Short Answer"}.get(q["type"], "Question")
                st.markdown(f"**Q{q['id']}** · `{type_label}`")
                st.markdown(f"**{q['question']}**")

                if q["type"] in ("mcq", "tf") and q.get("options"):
                    opts = q["options"]
                    if q["type"] == "mcq":
                        opts_labeled = [f"{chr(65+i)}. {o}" for i, o in enumerate(opts)]
                        choice = st.radio(
                            f"q{q['id']}",
                            opts_labeled,
                            key=f"radio_{q['id']}",
                            label_visibility="collapsed",
                        )
                        if choice:
                            answers[q["id"]] = choice[0]  # just the letter
                    else:
                        choice = st.radio(
                            f"q{q['id']}",
                            opts,
                            key=f"radio_{q['id']}",
                            label_visibility="collapsed",
                        )
                        if choice:
                            answers[q["id"]] = choice

                elif q["type"] == "short":
                    val = st.text_input(
                        "Your answer:",
                        key=f"short_{q['id']}",
                        placeholder="Type your answer here…",
                    )
                    if val:
                        answers[q["id"]] = val

                st.session_state.answers = answers

            st.markdown("---")
            answered = len([k for k in answers if answers[k]])
            if answered < len(questions):
                st.warning(f"Answer all questions to submit ({answered}/{len(questions)} answered)")
            if st.button("✅ Submit Quiz", type="primary", disabled=answered < len(questions)):
                st.session_state.submitted = True
                st.rerun()

        else:
            # Results
            results = []
            for q in questions:
                ua = str(answers.get(q["id"], "")).strip().lower()
                ca = str(q["answer"]).strip().lower()
                correct = (ua == ca or ca in ua or ua in ca) if q["type"] == "short" else ua == ca
                results.append({**q, "user_answer": answers.get(q["id"], ""), "correct": correct})

            correct_count = sum(1 for r in results if r["correct"])
            pct = round((correct_count / len(results)) * 100)

            # Score display
            emoji = "🎉" if pct >= 80 else "👍" if pct >= 60 else "📚"
            msg = "Excellent!" if pct >= 80 else "Good effort!" if pct >= 60 else "Keep practicing!"
            st.markdown(
                f'<div class="score-box"><h1 style="font-size:3rem;margin:0">{pct}%</h1>'
                f'<p style="font-size:1.2rem;margin:.5rem 0 0">{emoji} {msg}</p>'
                f'<p style="opacity:.7">{correct_count} / {len(results)} correct</p></div>',
                unsafe_allow_html=True,
            )

            c1, c2, c3 = st.columns(3)
            c1.metric("✅ Correct", correct_count)
            c2.metric("❌ Wrong", len(results) - correct_count)
            c3.metric("🎯 Score", f"{pct}%")

            st.markdown("### Review Answers")
            for r in results:
                status = "q-correct" if r["correct"] else "q-wrong"
                icon = "✅" if r["correct"] else "❌"
                exp = f"<br><small style='color:#888'>💡 {r['explanation']}</small>" if r.get("explanation") else ""
                ans_text = (
                    f"<span style='color:#34d399'>Your answer: {r['user_answer']} ✓</span>"
                    if r["correct"]
                    else f"<span style='color:#f87171'>Your: {r['user_answer'] or '(none)'}</span> &nbsp;·&nbsp; "
                         f"<span style='color:#34d399'>Correct: {r['answer']}</span>"
                )
                st.markdown(
                    f'<div class="q-card {status}">'
                    f'<strong>{icon} Q{r["id"]}: {r["question"]}</strong><br>'
                    f'{ans_text}{exp}</div>',
                    unsafe_allow_html=True,
                )

            if st.button("↺ Retake Quiz"):
                st.session_state.answers = {}
                st.session_state.submitted = False
                st.rerun()


# ── TAB 3: Raw API Test ───────────────────────────────────────────────────────
with tab_raw_api:
    st.markdown("### Direct API Testing")
    st.markdown("Test the API endpoints directly. Useful for debugging your React frontend integration.")

    col1, col2 = st.columns(2)
    with col1:
        st.markdown("**GET /health**")
        if st.button("Test /health"):
            try:
                r = requests.get(f"{api_url}/health", timeout=5)
                st.json(r.json())
            except Exception as e:
                st.error(str(e))

    with col2:
        st.markdown("**GET /**")
        if st.button("Test / (root)"):
            try:
                r = requests.get(f"{api_url}/", timeout=5)
                st.json(r.json())
            except Exception as e:
                st.error(str(e))

    st.markdown("---")
    st.markdown("**React Frontend Integration Example**")
    st.code("""
// Streaming quiz generation from your React app
const formData = new FormData();
formData.append("file", selectedFile);
formData.append("num_questions", 5);
formData.append("question_type", "Multiple Choice");
formData.append("difficulty", "Medium");

const response = await fetch("http://YOUR_SERVER:8000/generate-quiz-stream", {
  method: "POST",
  body: formData,
});

const reader = response.body.getReader();
const decoder = new TextDecoder();

while (true) {
  const { done, value } = await reader.read();
  if (done) break;
  const chunk = decoder.decode(value);
  for (const line of chunk.split("\\n")) {
    if (!line.startsWith("data: ")) continue;
    const event = JSON.parse(line.slice(6));
    if (event.type === "token") {
      setStreamedText(prev => prev + event.token); // word by word
    } else if (event.type === "done") {
      setQuiz(event.quiz); // final parsed quiz
    }
  }
}
    """, language="javascript")

    st.markdown("**API Docs (Swagger UI)**")
    st.markdown(f"Open: [{api_url}/docs]({api_url}/docs)")
