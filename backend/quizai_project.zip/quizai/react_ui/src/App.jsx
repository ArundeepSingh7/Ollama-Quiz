// react_ui/src/App.jsx
// Connect this to your backend by setting VITE_API_URL in .env
// Default: http://localhost:8000

import { useState, useRef } from "react";

const API = import.meta.env.VITE_API_URL || "http://localhost:8000";

const DIFFICULTIES = ["Easy", "Medium", "Hard"];
const Q_TYPES = ["Multiple Choice", "True / False", "Short Answer", "Mixed"];

export default function App() {
  const [file, setFile]           = useState(null);
  const [numQ, setNumQ]           = useState(5);
  const [qType, setQType]         = useState("Multiple Choice");
  const [diff, setDiff]           = useState("Medium");
  const [phase, setPhase]         = useState("upload"); // upload|config|generating|quiz|results
  const [streamed, setStreamed]   = useState("");
  const [quiz, setQuiz]           = useState(null);
  const [answers, setAnswers]     = useState({});
  const [score, setScore]         = useState(null);
  const [error, setError]         = useState("");
  const [drag, setDrag]           = useState(false);
  const [docMeta, setDocMeta]     = useState(null);
  const fileRef                   = useRef();

  // ── File handling ──────────────────────────────────────────────────────────
  const handleFile = async (f) => {
    if (!f) return;
    const ext = f.name.split(".").pop().toLowerCase();
    if (!["pdf","doc","docx"].includes(ext)) {
      setError("Please upload a PDF or Word (.doc/.docx) file."); return;
    }
    setError(""); setFile(f);

    // Extract text & get meta from server
    const fd = new FormData();
    fd.append("file", f);
    try {
      const r = await fetch(`${API}/extract-text`, { method: "POST", body: fd });
      if (!r.ok) throw new Error(await r.text());
      const meta = await r.json();
      setDocMeta(meta);
      setNumQ(Math.min(numQ, meta.max_recommended_questions));
      setPhase("config");
    } catch (e) {
      setError("Could not read file: " + e.message);
    }
  };

  // ── Generate quiz (streaming) ──────────────────────────────────────────────
  const generate = async () => {
    setPhase("generating"); setStreamed(""); setError("");
    const fd = new FormData();
    fd.append("file", file);
    fd.append("num_questions", numQ);
    fd.append("question_type", qType);
    fd.append("difficulty", diff);

    try {
      const resp = await fetch(`${API}/generate-quiz-stream`, { method: "POST", body: fd });
      if (!resp.ok) throw new Error(await resp.text());

      const reader = resp.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop(); // keep incomplete line

        for (const line of lines) {
          if (!line.startsWith("data: ")) continue;
          try {
            const event = JSON.parse(line.slice(6));
            if (event.type === "token") {
              setStreamed(s => s + event.token);
            } else if (event.type === "done") {
              setQuiz(event.quiz);
              setAnswers({});
              setScore(null);
              setPhase("quiz");
            } else if (event.type === "error") {
              throw new Error(event.message);
            }
          } catch {}
        }
      }
    } catch (e) {
      setError("Generation failed: " + e.message);
      setPhase("config");
    }
  };

  // ── Submit ─────────────────────────────────────────────────────────────────
  const submit = () => {
    const results = quiz.questions.map(q => {
      const ua = (answers[q.id] || "").trim().toLowerCase();
      const ca = q.answer.trim().toLowerCase();
      const correct = q.type === "short"
        ? (ua.length > 0 && (ca.includes(ua) || ua.includes(ca)))
        : ua === ca;
      return { ...q, userAnswer: answers[q.id] || "", correct };
    });
    const correct = results.filter(r => r.correct).length;
    setScore({ results, correct, total: results.length, pct: Math.round(correct / results.length * 100) });
    setPhase("results");
  };

  const answered = Object.keys(answers).length;
  const totalQ   = quiz?.questions?.length || 0;

  return (
    <div style={s.wrap}>
      {/* Header */}
      <div style={s.header}>
        <div style={s.badge}>🔓 Open Source · Runs on Server · Free for Everyone</div>
        <h1 style={s.h1}>AI Quiz Generator</h1>
        <p style={s.sub}>Upload a document — AI generates a quiz instantly. Free forever.</p>
      </div>

      {/* Upload */}
      {phase === "upload" && (
        <div style={s.card}>
          <div style={s.clabel}>Upload Document</div>
          <div
            style={{ ...s.drop, ...(drag ? s.dropActive : {}) }}
            onClick={() => fileRef.current?.click()}
            onDragOver={e => { e.preventDefault(); setDrag(true); }}
            onDragLeave={() => setDrag(false)}
            onDrop={e => { e.preventDefault(); setDrag(false); handleFile(e.dataTransfer.files[0]); }}
          >
            <div style={{ fontSize: "3rem", marginBottom: "0.8rem" }}>📄</div>
            <p style={s.dropMain}>Drop file here or click to browse</p>
            <p style={s.dropHint}>PDF, DOC, DOCX — processed on server, not your device</p>
          </div>
          <input ref={fileRef} type="file" accept=".pdf,.doc,.docx" style={{ display:"none" }}
            onChange={e => handleFile(e.target.files[0])} />
          {error && <div style={s.err}>{error}</div>}
        </div>
      )}

      {/* Config */}
      {phase === "config" && (
        <>
          <div style={s.card}>
            <div style={s.clabel}>Document</div>
            <div style={s.pill}>
              📎 {file?.name}
              {docMeta && <span style={s.pillMeta}>{docMeta.word_count} words · max {docMeta.max_recommended_questions}Q</span>}
              <span style={s.pillX} onClick={() => { setFile(null); setDocMeta(null); setPhase("upload"); }}>×</span>
            </div>
          </div>
          <div style={s.card}>
            <div style={s.clabel}>Quiz Settings</div>
            <div style={s.ctrlGrid}>
              <label style={s.lbl}>
                Question Type
                <select style={s.sel} value={qType} onChange={e => setQType(e.target.value)}>
                  {Q_TYPES.map(t => <option key={t}>{t}</option>)}
                </select>
              </label>
              <label style={s.lbl}>
                Difficulty
                <select style={s.sel} value={diff} onChange={e => setDiff(e.target.value)}>
                  {DIFFICULTIES.map(d => <option key={d}>{d}</option>)}
                </select>
              </label>
              <label style={s.lbl}>
                Questions: {numQ}
                <div style={{ display:"flex", alignItems:"center", gap:8, marginTop:8 }}>
                  <input type="range" min="3" max={docMeta?.max_recommended_questions || 20}
                    value={numQ} onChange={e => setNumQ(+e.target.value)} style={{ flex:1, accentColor:"#7c5cfc" }} />
                  <span style={{ fontWeight:800, color:"#a78bfa", minWidth:24 }}>{numQ}</span>
                </div>
              </label>
            </div>
            <button style={s.btn} onClick={generate}>✦ Generate Quiz</button>
            {error && <div style={s.err}>{error}</div>}
          </div>
        </>
      )}

      {/* Generating */}
      {phase === "generating" && (
        <div style={s.card}>
          <div style={{ display:"flex", alignItems:"center", gap:10, marginBottom:"1rem", color:"#6b6880" }}>
            <div style={s.spinner} /> AI is generating your quiz on the server…
          </div>
          <pre style={s.streamBox}>{streamed}<span style={s.cursor} /></pre>
        </div>
      )}

      {/* Quiz */}
      {phase === "quiz" && quiz && (
        <div style={s.card}>
          <button style={s.backBtn} onClick={() => setPhase("config")}>← Settings</button>
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:"1.5rem", flexWrap:"wrap", gap:"0.5rem" }}>
            <h2 style={{ color:"#fff", fontWeight:800 }}>{quiz.title}</h2>
            <span style={s.badge2}>{totalQ} questions · {diff}</span>
          </div>
          <div style={s.progWrap}><div style={{ ...s.progFill, width:`${(answered/totalQ)*100}%` }} /></div>

          {quiz.questions.map((q, i) => (
            <div key={q.id} style={s.qBlock}>
              <div style={s.qNum}>
                Q{i+1} <span style={s.qTag}>{q.type === "mcq" ? "MCQ" : q.type === "tf" ? "True/False" : "Short Answer"}</span>
              </div>
              <p style={s.qTxt}>{q.question}</p>
              {(q.type === "mcq" || q.type === "tf") && q.options?.length > 0 && (
                <div style={{ display:"grid", gap:8 }}>
                  {q.options.map((opt, oi) => {
                    const letter = q.type === "mcq" ? String.fromCharCode(65 + oi) : opt;
                    const sel = answers[q.id] === letter;
                    return (
                      <button key={oi} style={{ ...s.opt, ...(sel ? s.optSel : {}) }}
                        onClick={() => setAnswers(a => ({ ...a, [q.id]: letter }))}>
                        {q.type === "mcq" && <span style={s.optLtr}>{letter}</span>}
                        {opt}
                      </button>
                    );
                  })}
                </div>
              )}
              {q.type === "short" && (
                <input style={s.shortInp} placeholder="Type your answer…"
                  value={answers[q.id] || ""}
                  onChange={e => setAnswers(a => ({ ...a, [q.id]: e.target.value }))} />
              )}
            </div>
          ))}

          <button style={{ ...s.btn, marginTop:"1.5rem", opacity: answered < totalQ ? 0.4 : 1 }}
            onClick={submit} disabled={answered < totalQ}>
            {answered < totalQ ? `Answer all (${answered}/${totalQ})` : "✓ Submit Quiz"}
          </button>
        </div>
      )}

      {/* Results */}
      {phase === "results" && score && (
        <div style={s.card}>
          <div style={{ textAlign:"center", padding:"1.5rem 0 2rem" }}>
            <div style={s.scoreRing}>
              <div style={{ fontSize:"3rem", fontWeight:800, color:"#fff", lineHeight:1 }}>{score.pct}%</div>
              <div style={{ fontSize:"0.7rem", color:"rgba(255,255,255,.55)", letterSpacing:".1em", textTransform:"uppercase", marginTop:4 }}>Score</div>
            </div>
            <h2 style={{ color:"#fff", fontSize:"1.6rem", fontWeight:800, marginBottom:".4rem" }}>
              {score.pct >= 80 ? "🎉 Excellent!" : score.pct >= 60 ? "👍 Good effort!" : "📚 Keep practicing!"}
            </h2>
            <p style={{ color:"#6b6880" }}>{score.correct} of {score.total} correct</p>
          </div>

          <div style={{ display:"grid", gridTemplateColumns:"repeat(3,1fr)", gap:"1rem", marginBottom:"2rem" }}>
            {[["Correct", score.correct, "#34d399"], ["Wrong", score.total-score.correct, "#f87171"], ["Score", `${score.pct}%`, "#a78bfa"]].map(([k,v,c]) => (
              <div key={k} style={s.statCard}>
                <div style={{ fontSize:"1.7rem", fontWeight:800, color:c }}>{v}</div>
                <div style={{ fontSize:11, color:"#3a3850", textTransform:"uppercase", letterSpacing:".08em", fontWeight:700 }}>{k}</div>
              </div>
            ))}
          </div>

          <div style={s.clabel}>Review</div>
          {score.results.map((r, i) => (
            <div key={r.id} style={{ display:"flex", gap:12, padding:"1rem 0", borderBottom:"1px solid #1a1a2a" }}>
              <div style={{ ...s.rvIcon, ...(r.correct ? s.rvOk : s.rvBad) }}>{r.correct ? "✓" : "✗"}</div>
              <div style={{ flex:1 }}>
                <div style={{ fontSize:".9rem", fontWeight:600, color:"#e2e0f0", marginBottom:4 }}>Q{i+1}: {r.question}</div>
                <div style={{ fontSize:".82rem", color:"#6b6880" }}>
                  {r.correct
                    ? <span style={{ color:"#34d399" }}>Your answer: {r.userAnswer} ✓</span>
                    : <><span style={{ color:"#f87171" }}>Your: {r.userAnswer || "(none)"}</span>  ·  <span style={{ color:"#34d399" }}>Correct: {r.answer}</span></>}
                </div>
                {r.explanation && <div style={s.expl}><b>Explanation:</b> {r.explanation}</div>}
              </div>
            </div>
          ))}

          <div style={{ display:"flex", gap:"0.75rem", marginTop:"1.5rem", flexWrap:"wrap" }}>
            <button style={s.btnGhost} onClick={() => { setAnswers({}); setScore(null); setPhase("quiz"); }}>↺ Retake</button>
            <button style={s.btnGhost} onClick={() => setPhase("config")}>⚙ Settings</button>
            <button style={{ ...s.btn, flex:1 }} onClick={() => { setFile(null); setDocMeta(null); setQuiz(null); setAnswers({}); setScore(null); setPhase("upload"); }}>+ New Document</button>
          </div>
        </div>
      )}
    </div>
  );
}

// ── Styles ────────────────────────────────────────────────────────────────────
const s = {
  wrap:      { maxWidth:860, margin:"0 auto", padding:"2.5rem 1.5rem 5rem", fontFamily:"'Plus Jakarta Sans',system-ui,sans-serif", background:"#0b0b14", minHeight:"100vh" },
  header:    { textAlign:"center", marginBottom:"3rem" },
  badge:     { display:"inline-block", background:"rgba(124,92,252,.12)", border:"1px solid rgba(124,92,252,.3)", color:"#a78bfa", fontSize:11, fontWeight:700, letterSpacing:".12em", textTransform:"uppercase", padding:"6px 16px", borderRadius:100, marginBottom:"1rem" },
  h1:        { fontSize:"2.5rem", fontWeight:800, background:"linear-gradient(135deg,#fff 30%,#a78bfa)", WebkitBackgroundClip:"text", WebkitTextFillColor:"transparent", backgroundClip:"text", lineHeight:1.15, marginBottom:".5rem" },
  sub:       { color:"#6b6880", fontSize:".95rem" },
  card:      { background:"#13131f", border:"1px solid #252535", borderRadius:20, padding:"2rem", marginBottom:"1.5rem" },
  clabel:    { fontSize:11, fontWeight:700, letterSpacing:".12em", textTransform:"uppercase", color:"#3a3850", marginBottom:"1.2rem", display:"flex", alignItems:"center", gap:8 },
  drop:      { border:"2px dashed #252535", borderRadius:14, padding:"3rem 2rem", textAlign:"center", cursor:"pointer", transition:"all .2s", background:"#0b0b14" },
  dropActive:{ borderColor:"#7c5cfc", background:"rgba(124,92,252,.05)" },
  dropMain:  { fontSize:"1rem", fontWeight:600, color:"#e2e0f0", marginBottom:".3rem" },
  dropHint:  { fontSize:".82rem", color:"#4a4860" },
  pill:      { display:"inline-flex", alignItems:"center", gap:10, background:"rgba(124,92,252,.1)", border:"1px solid rgba(124,92,252,.25)", color:"#a78bfa", padding:"9px 16px", borderRadius:100, fontSize:".88rem", fontWeight:600 },
  pillMeta:  { background:"rgba(255,255,255,.06)", padding:"2px 8px", borderRadius:100, fontSize:11, color:"#6b6880" },
  pillX:     { cursor:"pointer", opacity:.5, fontSize:18, lineHeight:1, transition:"opacity .15s" },
  ctrlGrid:  { display:"grid", gridTemplateColumns:"1fr 1fr 1fr", gap:"1rem", marginBottom:"1.2rem" },
  lbl:       { display:"flex", flexDirection:"column", fontSize:11, fontWeight:700, letterSpacing:".08em", textTransform:"uppercase", color:"#4a4860", gap:8 },
  sel:       { padding:"10px 14px", background:"#0b0b14", border:"1.5px solid #252535", borderRadius:10, fontFamily:"inherit", fontSize:".88rem", color:"#e2e0f0", outline:"none", cursor:"pointer" },
  btn:       { width:"100%", padding:"14px 28px", background:"linear-gradient(135deg,#7c5cfc,#5c3fcc)", color:"#fff", border:"none", borderRadius:12, fontFamily:"inherit", fontSize:"1rem", fontWeight:700, cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center", gap:10 },
  btnGhost:  { background:"transparent", border:"1.5px solid #252535", color:"#6b6880", padding:"10px 20px", fontSize:".9rem", fontWeight:600, borderRadius:10, fontFamily:"inherit", cursor:"pointer" },
  backBtn:   { background:"none", border:"none", color:"#4a4860", fontFamily:"inherit", fontSize:".85rem", cursor:"pointer", marginBottom:"1.5rem", display:"flex", alignItems:"center", gap:6, padding:0 },
  spinner:   { width:18, height:18, border:"2px solid #252535", borderTopColor:"#7c5cfc", borderRadius:"50%", animation:"spin .7s linear infinite" },
  streamBox: { background:"#06060f", border:"1px solid #181828", borderRadius:12, padding:"1.4rem", minHeight:160, fontFamily:"monospace", fontSize:".75rem", color:"#50fa7b", lineHeight:1.85, overflowY:"auto", maxHeight:300, whiteSpace:"pre-wrap", wordBreak:"break-all" },
  cursor:    { display:"inline-block", width:2, height:"1.1em", background:"#50fa7b", animation:"blink 1s step-end infinite", verticalAlign:"text-bottom", marginLeft:1 },
  progWrap:  { background:"#1a1a2a", borderRadius:100, height:5, marginBottom:"2rem", overflow:"hidden" },
  progFill:  { height:"100%", background:"linear-gradient(90deg,#7c5cfc,#a78bfa)", borderRadius:100, transition:"width .4s ease" },
  qBlock:    { marginBottom:"2rem", paddingBottom:"2rem", borderBottom:"1px solid #1a1a2a" },
  qNum:      { fontSize:11, fontWeight:700, letterSpacing:".1em", textTransform:"uppercase", color:"#3a3850", marginBottom:".5rem", display:"flex", alignItems:"center", gap:8 },
  qTag:      { background:"rgba(124,92,252,.1)", color:"#a78bfa", fontSize:10, padding:"2px 8px", borderRadius:100, textTransform:"uppercase" },
  qTxt:      { fontSize:"1rem", fontWeight:600, color:"#e2e0f0", lineHeight:1.65, marginBottom:"1.2rem" },
  opt:       { width:"100%", textAlign:"left", padding:"12px 16px", borderRadius:10, border:"1.5px solid #252535", background:"#0b0b14", fontFamily:"inherit", fontSize:".9rem", color:"#6b6880", cursor:"pointer", display:"flex", alignItems:"center", gap:12 },
  optSel:    { borderColor:"#7c5cfc", background:"rgba(124,92,252,.1)", color:"#a78bfa" },
  optLtr:    { fontWeight:800, fontSize:".8rem", minWidth:22, opacity:.4 },
  shortInp:  { width:"100%", padding:"12px 16px", background:"#0b0b14", border:"1.5px solid #252535", borderRadius:10, fontFamily:"inherit", fontSize:".92rem", color:"#e2e0f0", outline:"none" },
  expl:      { marginTop:".9rem", padding:"12px 16px", background:"rgba(124,92,252,.06)", borderRadius:10, fontSize:".84rem", color:"#6b6880", lineHeight:1.65, borderLeft:"2px solid #7c5cfc" },
  badge2:    { background:"rgba(124,92,252,.1)", border:"1px solid rgba(124,92,252,.2)", color:"#a78bfa", fontSize:11, fontWeight:700, padding:"5px 12px", borderRadius:100 },
  scoreRing: { width:150, height:150, borderRadius:"50%", background:"linear-gradient(135deg,#7c5cfc,#5c3fcc)", display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", margin:"0 auto 1.5rem", boxShadow:"0 0 50px rgba(124,92,252,.3)" },
  statCard:  { background:"#0b0b14", border:"1px solid #252535", borderRadius:14, padding:"1.2rem", textAlign:"center" },
  rvIcon:    { width:26, height:26, borderRadius:"50%", flexShrink:0, display:"flex", alignItems:"center", justifyContent:"center", fontSize:12, fontWeight:800, marginTop:2 },
  rvOk:      { background:"rgba(52,211,153,.1)", color:"#34d399" },
  rvBad:     { background:"rgba(248,113,113,.08)", color:"#f87171" },
  err:       { background:"rgba(248,113,113,.06)", border:"1px solid rgba(248,113,113,.2)", borderRadius:10, padding:"1rem 1.2rem", color:"#fca5a5", fontSize:".88rem", marginTop:"1rem" },
};
