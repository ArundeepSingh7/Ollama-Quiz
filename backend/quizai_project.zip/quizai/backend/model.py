"""
ModelManager — loads the open-source model once and keeps it in memory.

Default model: Qwen/Qwen2.5-0.5B-Instruct  (~500 MB, fast)
Better model:  Qwen/Qwen2.5-1.5B-Instruct  (~1 GB, more accurate)
Best model:    Qwen/Qwen2.5-3B-Instruct     (~2 GB, high quality)

Change MODEL_NAME in config.py or set env var QUIZ_MODEL to switch.
All models are free and open-source from Hugging Face.
"""

import os
import asyncio
import threading
from typing import AsyncGenerator, Optional
import torch
from transformers import (
    AutoTokenizer,
    AutoModelForCausalLM,
    TextIteratorStreamer,
    BitsAndBytesConfig,
)
from config import MODEL_NAME, USE_4BIT, MAX_CONTEXT_LENGTH

class ModelManager:
    def __init__(self):
        self.model = None
        self.tokenizer = None
        self.model_name = MODEL_NAME
        self._ready = False

    def is_ready(self) -> bool:
        return self._ready

    def load(self):
        """Load model and tokenizer. Called once at startup."""
        print(f"   Model: {self.model_name}")
        print(f"   4-bit quantization: {USE_4BIT}")

        # Detect device
        if torch.cuda.is_available():
            device = "cuda"
            print(f"   Device: GPU ({torch.cuda.get_device_name(0)})")
        elif torch.backends.mps.is_available():
            device = "mps"
            print(f"   Device: Apple Silicon MPS")
        else:
            device = "cpu"
            print(f"   Device: CPU (slower, but works)")

        self.device = device

        # Quantization config for GPU (saves VRAM)
        quant_config = None
        if USE_4BIT and device == "cuda":
            quant_config = BitsAndBytesConfig(
                load_in_4bit=True,
                bnb_4bit_compute_dtype=torch.float16,
                bnb_4bit_quant_type="nf4",
                bnb_4bit_use_double_quant=True,
            )

        # Load tokenizer
        print("   Loading tokenizer...")
        self.tokenizer = AutoTokenizer.from_pretrained(
            self.model_name,
            trust_remote_code=True,
        )
        if self.tokenizer.pad_token is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token

        # Load model
        print("   Loading model weights (first run downloads from HuggingFace)...")
        load_kwargs = dict(
            trust_remote_code=True,
            torch_dtype=torch.float16 if device != "cpu" else torch.float32,
            low_cpu_mem_usage=True,
        )
        if quant_config:
            load_kwargs["quantization_config"] = quant_config
        elif device != "cpu":
            load_kwargs["device_map"] = "auto"

        self.model = AutoModelForCausalLM.from_pretrained(self.model_name, **load_kwargs)

        if device == "cpu":
            self.model = self.model.to("cpu")

        self.model.eval()
        self._ready = True
        print(f"   ✅ Model loaded successfully on {device.upper()}")

    def _build_input(self, prompt: str) -> dict:
        """Format prompt as chat message and tokenize."""
        messages = [{"role": "user", "content": prompt}]
        text = self.tokenizer.apply_chat_template(
            messages,
            tokenize=False,
            add_generation_prompt=True,
        )
        return self.tokenizer(
            text,
            return_tensors="pt",
            truncation=True,
            max_length=MAX_CONTEXT_LENGTH,
        ).to(self.device if hasattr(self, 'device') else 'cpu')

    def generate(self, prompt: str, max_new_tokens: int = 2000) -> str:
        """Synchronous (blocking) generation. Returns full output string."""
        inputs = self._build_input(prompt)
        with torch.no_grad():
            output_ids = self.model.generate(
                **inputs,
                max_new_tokens=max_new_tokens,
                do_sample=False,
                temperature=None,
                top_p=None,
                pad_token_id=self.tokenizer.eos_token_id,
                eos_token_id=self.tokenizer.eos_token_id,
            )
        # Decode only the new tokens (skip the prompt)
        new_tokens = output_ids[0][inputs["input_ids"].shape[1]:]
        return self.tokenizer.decode(new_tokens, skip_special_tokens=True)

    async def generate_stream(
        self, prompt: str, max_new_tokens: int = 2000
    ) -> AsyncGenerator[str, None]:
        """
        Async streaming generation using TextIteratorStreamer.
        Yields tokens one by one as they are generated.
        """
        inputs = self._build_input(prompt)
        streamer = TextIteratorStreamer(
            self.tokenizer,
            skip_prompt=True,
            skip_special_tokens=True,
        )

        gen_kwargs = dict(
            **inputs,
            max_new_tokens=max_new_tokens,
            do_sample=False,
            temperature=None,
            top_p=None,
            pad_token_id=self.tokenizer.eos_token_id,
            eos_token_id=self.tokenizer.eos_token_id,
            streamer=streamer,
        )

        # Run generation in a background thread so we don't block the event loop
        thread = threading.Thread(
            target=lambda: self.model.generate(**gen_kwargs),
            daemon=True,
        )
        thread.start()

        # Yield tokens from the streamer as they arrive
        loop = asyncio.get_event_loop()
        for token in streamer:
            yield token
            await asyncio.sleep(0)  # let FastAPI send the chunk immediately
