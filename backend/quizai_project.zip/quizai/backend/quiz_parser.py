"""
quiz_parser.py — Build prompts for quiz generation and parse the AI output.
"""

import json
import re
from typing import Optional
from config import MAX_DOC_CHARS


# ─── Prompt Builder ──────────────────────────────────────────────────────────

def build_prompt(doc_text: str, num_questions: int, question_type: str, difficulty: str) -> str:
    """Build the instruction prompt sent to the model."""

    # Truncate document to avoid exceeding context window
    truncated = doc_text[:MAX_DOC_CHARS]
    if len(doc_text) > MAX_DOC_CHARS:
        truncated += "\n[... document truncated for length ...]"

    # Build format description and example based on question type
    if question_type == "Multiple Choice":
        fmt = (
            'type must be "mcq". Provide exactly 4 options array. '
            'answer must be the LETTER of the correct option: "A", "B", "C", or "D".'
        )
        example = (
            '{"id":1,"type":"mcq","question":"What is X?","options":'
            '["First","Second","Third","Fourth"],"answer":"A","explanation":"Because..."}'
        )
    elif question_type == "True / False":
        fmt = (
            'type must be "tf". options must be exactly ["True","False"]. '
            'answer must be exactly "True" or "False".'
        )
        example = (
            '{"id":1,"type":"tf","question":"Is it true that X?","options":'
            '["True","False"],"answer":"True","explanation":"Because..."}'
        )
    elif question_type == "Short Answer":
        fmt = (
            'type must be "short". Do NOT include an options field. '
            'answer must be a short key phrase (1-5 words).'
        )
        example = (
            '{"id":1,"type":"short","question":"What is the name of X?","answer":"key phrase",'
            '"explanation":"Because..."}'
        )
    else:  # Mixed
        fmt = (
            'Mix of types: "mcq" (with 4 options, letter answer), '
            '"tf" (with True/False options), and "short" (no options, phrase answer).'
        )
        example = (
            '{"id":1,"type":"mcq","question":"...?","options":["A","B","C","D"],'
            '"answer":"A","explanation":"..."}'
        )

    prompt = f"""You are an expert quiz generator. Generate exactly {num_questions} {difficulty} difficulty questions from the text below.

OUTPUT FORMAT: Return ONLY a single valid JSON object. No explanation, no markdown, no code blocks.

Required JSON structure:
{{"title":"Short quiz title","questions":[{example}]}}

Rules:
- Generate EXACTLY {num_questions} questions
- {fmt}  
- Every question must have: id, type, question, answer, explanation
- Questions must be directly answerable from the provided text
- Explanations should briefly explain why the answer is correct
- The "title" should summarize the topic of the document

TEXT:
\"\"\"
{truncated}
\"\"\"

JSON:"""

    return prompt


# ─── Output Parser ───────────────────────────────────────────────────────────

def parse_quiz_output(raw_text: str) -> Optional[dict]:
    """
    Try multiple strategies to extract valid JSON from the model output.
    Models sometimes add extra text, markdown, or cut off mid-generation.
    """
    text = raw_text.strip()

    # Strategy 1: direct parse
    quiz = _try_parse(text)
    if quiz:
        return _normalize(quiz)

    # Strategy 2: strip markdown code fences
    text_clean = re.sub(r"```(?:json)?", "", text).strip()
    quiz = _try_parse(text_clean)
    if quiz:
        return _normalize(quiz)

    # Strategy 3: find the outermost JSON object
    match = re.search(r'\{[\s\S]*"questions"[\s\S]*\}', text_clean)
    if match:
        quiz = _try_parse(match.group(0))
        if quiz:
            return _normalize(quiz)

    # Strategy 4: find from first { to last }
    start = text_clean.find('{"title"')
    if start == -1:
        start = text_clean.find('{')
    end = text_clean.rfind('}')
    if start >= 0 and end > start:
        quiz = _try_parse(text_clean[start:end + 1])
        if quiz:
            return _normalize(quiz)

    # Strategy 5: fix truncated JSON (model ran out of tokens mid-stream)
    quiz = _fix_truncated(text_clean)
    if quiz:
        return _normalize(quiz)

    return None


def _try_parse(text: str) -> Optional[dict]:
    try:
        obj = json.loads(text)
        if isinstance(obj, dict) and "questions" in obj:
            return obj
    except (json.JSONDecodeError, ValueError):
        pass
    return None


def _fix_truncated(text: str) -> Optional[dict]:
    """Attempt to salvage a truncated JSON response by closing open brackets."""
    t = text.strip()

    # Remove last incomplete question object
    last_complete = max(
        t.rfind('},"'),   # end of a question, followed by next key
        t.rfind('"}'),    # closing a string then object
    )
    if last_complete > 0:
        t = t[:last_complete + 2]

    # Count open brackets and close them
    opens_curly = t.count('{') - t.count('}')
    opens_square = t.count('[') - t.count(']')

    t += ']' * max(0, opens_square)
    t += '}' * max(0, opens_curly)

    return _try_parse(t)


def _normalize(quiz: dict) -> dict:
    """Ensure all questions have required fields and normalize values."""
    questions = quiz.get("questions", [])
    normalized = []

    for i, q in enumerate(questions):
        if not q.get("question"):
            continue

        qtype = str(q.get("type", "mcq")).lower()

        # Normalize type
        if qtype not in ("mcq", "tf", "short"):
            if q.get("options"):
                qtype = "tf" if len(q["options"]) == 2 else "mcq"
            else:
                qtype = "short"

        # Normalize answer
        answer = str(q.get("answer", "")).strip()
        if qtype == "mcq":
            # Accept full text answer and convert to letter
            opts = q.get("options", [])
            if answer and len(answer) > 1 and opts:
                for idx, opt in enumerate(opts):
                    if answer.lower() == opt.lower():
                        answer = chr(65 + idx)
                        break
            if answer not in ("A", "B", "C", "D"):
                answer = "A"

        normalized.append({
            "id": i + 1,
            "type": qtype,
            "question": q["question"].strip(),
            "options": q.get("options", []),
            "answer": answer,
            "explanation": q.get("explanation", ""),
        })

    return {
        "title": quiz.get("title", "Quiz"),
        "questions": normalized,
    }
