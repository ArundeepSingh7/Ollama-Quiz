"""
extractor.py — Extract plain text from PDF and Word files.
Uses only free, open-source libraries.
"""

import io
from pathlib import Path


def extract_text_from_file(content: bytes, filename: str) -> str:
    """
    Extract text from file bytes.
    Supports: .pdf, .doc, .docx
    """
    ext = Path(filename).suffix.lower()

    if ext == ".pdf":
        return _extract_pdf(content)
    elif ext in (".doc", ".docx"):
        return _extract_word(content)
    else:
        raise ValueError(f"Unsupported file type: {ext}. Please upload PDF or Word (.doc/.docx).")


def _extract_pdf(content: bytes) -> str:
    """Extract text from PDF using PyMuPDF (fitz) — fast and accurate."""
    try:
        import fitz  # PyMuPDF
        doc = fitz.open(stream=content, filetype="pdf")
        text_parts = []
        for page in doc:
            text_parts.append(page.get_text("text"))
        doc.close()
        text = "\n".join(text_parts).strip()
        if not text:
            raise ValueError("PDF appears to be scanned/image-only. No text could be extracted.")
        return text
    except ImportError:
        # Fallback to pdfplumber if PyMuPDF not available
        return _extract_pdf_fallback(content)


def _extract_pdf_fallback(content: bytes) -> str:
    """Fallback PDF extractor using pdfplumber."""
    try:
        import pdfplumber
        with pdfplumber.open(io.BytesIO(content)) as pdf:
            pages = [page.extract_text() or "" for page in pdf.pages]
        text = "\n".join(pages).strip()
        if not text:
            raise ValueError("Could not extract text from PDF.")
        return text
    except ImportError:
        raise ImportError(
            "No PDF library found. Install one:\n"
            "  pip install PyMuPDF\n"
            "  OR\n"
            "  pip install pdfplumber"
        )


def _extract_word(content: bytes) -> str:
    """Extract text from .doc and .docx using python-docx."""
    try:
        from docx import Document
        doc = Document(io.BytesIO(content))
        paragraphs = [p.text for p in doc.paragraphs if p.text.strip()]
        # Also extract table content
        for table in doc.tables:
            for row in table.rows:
                for cell in row.cells:
                    if cell.text.strip():
                        paragraphs.append(cell.text.strip())
        text = "\n".join(paragraphs).strip()
        if not text:
            raise ValueError("Word file appears to be empty or has no readable text.")
        return text
    except ImportError:
        raise ImportError("python-docx not installed. Run: pip install python-docx")
