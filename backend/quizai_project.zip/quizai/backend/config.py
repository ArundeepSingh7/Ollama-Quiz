"""
config.py — Change your model and settings here.

All models below are FREE and open-source (Hugging Face).
They are downloaded automatically on first run and cached locally.

─────────────────────────────────────────────────────────────────
MODEL OPTIONS (choose one):
─────────────────────────────────────────────────────────────────

FAST / LOW RESOURCE:
  "Qwen/Qwen2.5-0.5B-Instruct"      ~500 MB  | Good for low-RAM servers
  "Qwen/Qwen2.5-1.5B-Instruct"      ~1 GB    | Better quality, still fast

BALANCED (Recommended):
  "Qwen/Qwen2.5-3B-Instruct"        ~2 GB    | Great quality
  "microsoft/Phi-3-mini-4k-instruct" ~2.3 GB  | Very good at structured output

HIGH QUALITY (needs 8GB+ RAM/VRAM):
  "Qwen/Qwen2.5-7B-Instruct"        ~4.5 GB  | Excellent quality
  "mistralai/Mistral-7B-Instruct-v0.3" ~4.5 GB | Top-tier open source

─────────────────────────────────────────────────────────────────
You can also override via environment variable:
  export QUIZ_MODEL="Qwen/Qwen2.5-3B-Instruct"
─────────────────────────────────────────────────────────────────
"""

import os

# ── Model selection ──────────────────────────────────────────────────────────
MODEL_NAME: str = os.getenv(
    "QUIZ_MODEL",
    "Qwen/Qwen2.5-1.5B-Instruct"   # ← change this to your preferred model
)

# ── Quantization (GPU only) ──────────────────────────────────────────────────
# Set True to load model in 4-bit (saves ~75% VRAM, slight quality drop)
# Requires: pip install bitsandbytes  (only works on CUDA GPU)
USE_4BIT: bool = os.getenv("USE_4BIT", "false").lower() == "true"

# ── Context window ───────────────────────────────────────────────────────────
# Max tokens for the input prompt (document text gets truncated to fit)
MAX_CONTEXT_LENGTH: int = int(os.getenv("MAX_CONTEXT", "4096"))

# ── Document text truncation ─────────────────────────────────────────────────
# Max characters of document text sent to the model
MAX_DOC_CHARS: int = int(os.getenv("MAX_DOC_CHARS", "8000"))

# ── Server settings ──────────────────────────────────────────────────────────
HOST: str = os.getenv("HOST", "0.0.0.0")
PORT: int = int(os.getenv("PORT", "8000"))
