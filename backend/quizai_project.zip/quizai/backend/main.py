"""
QuizAI Backend — FastAPI server
Loads the AI model ONCE on startup, serves all requests from memory.
"""

from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.responses import StreamingResponse
from fastapi.middleware.cors import CORSMiddleware
import uvicorn
import json
import asyncio
from typing import Optional
from contextlib import asynccontextmanager

from model import ModelManager
from extractor import extract_text_from_file
from quiz_parser import parse_quiz_output, build_prompt

# ─── Lifespan: load model once on startup ───────────────────────────────────
manager = ModelManager()

@asynccontextmanager
async def lifespan(app: FastAPI):
    print("\n🚀 Loading AI model on startup (one-time only)...")
    manager.load()
    print("✅ Model ready! Server accepting requests.\n")
    yield
    print("🛑 Shutting down.")

app = FastAPI(
    title="QuizAI API",
    description="Generate quizzes from PDF/Word documents using a local open-source AI model.",
    version="1.0.0",
    lifespan=lifespan,
)

# Allow React frontend to call this API
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],          # restrict to your domain in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ─── Routes ─────────────────────────────────────────────────────────────────

@app.get("/")
def root():
    return {"status": "running", "model": manager.model_name, "ready": manager.is_ready()}


@app.get("/health")
def health():
    return {"healthy": manager.is_ready(), "model_loaded": manager.is_ready()}


@app.post("/extract-text")
async def extract_text(file: UploadFile = File(...)):
    """Extract raw text from an uploaded PDF or Word file."""
    try:
        content = await file.read()
        text = extract_text_from_file(content, file.filename)
        word_count = len(text.split())
        max_questions = min(20, max(3, word_count // 60))
        return {
            "filename": file.filename,
            "text_preview": text[:500] + "..." if len(text) > 500 else text,
            "word_count": word_count,
            "char_count": len(text),
            "max_recommended_questions": max_questions,
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/generate-quiz")
async def generate_quiz(
    file: UploadFile = File(...),
    num_questions: int = Form(5),
    question_type: str = Form("Multiple Choice"),
    difficulty: str = Form("Medium"),
):
    """
    Generate a quiz from an uploaded document.
    Returns the full quiz as JSON (non-streaming).
    """
    if not manager.is_ready():
        raise HTTPException(status_code=503, detail="Model not loaded yet. Try again in a moment.")

    try:
        content = await file.read()
        doc_text = extract_text_from_file(content, file.filename)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Could not read file: {e}")

    prompt = build_prompt(doc_text, num_questions, question_type, difficulty)

    try:
        output = manager.generate(prompt, max_new_tokens=min(3000, num_questions * 250))
        quiz = parse_quiz_output(output)
        if not quiz or not quiz.get("questions"):
            raise ValueError("Model did not return a valid quiz structure.")
        return {"success": True, "quiz": quiz, "raw_output": output}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Generation failed: {e}")


@app.post("/generate-quiz-stream")
async def generate_quiz_stream(
    file: UploadFile = File(...),
    num_questions: int = Form(5),
    question_type: str = Form("Multiple Choice"),
    difficulty: str = Form("Medium"),
):
    """
    Generate a quiz with streaming — tokens arrive word by word (Server-Sent Events).
    Frontend receives tokens live, then the final parsed quiz at the end.
    """
    if not manager.is_ready():
        raise HTTPException(status_code=503, detail="Model not loaded yet.")

    try:
        content = await file.read()
        doc_text = extract_text_from_file(content, file.filename)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Could not read file: {e}")

    prompt = build_prompt(doc_text, num_questions, question_type, difficulty)

    async def event_generator():
        full_text = ""
        try:
            async for token in manager.generate_stream(prompt, max_new_tokens=min(3000, num_questions * 250)):
                full_text += token
                # Send each token as an SSE event
                data = json.dumps({"type": "token", "token": token})
                yield f"data: {data}\n\n"
                await asyncio.sleep(0)   # yield control to event loop

            # After streaming, parse and send the final quiz
            quiz = parse_quiz_output(full_text)
            if quiz and quiz.get("questions"):
                data = json.dumps({"type": "done", "quiz": quiz})
            else:
                data = json.dumps({"type": "error", "message": "Could not parse quiz output."})
            yield f"data: {data}\n\n"

        except Exception as e:
            data = json.dumps({"type": "error", "message": str(e)})
            yield f"data: {data}\n\n"

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",   # disable nginx buffering
        },
    )


if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=False)
