# 🧠 QuizAI — Server-Side AI Quiz Generator

A complete, **100% free & open-source** quiz generation system.
- AI model runs **on your server** — users never download anything
- Supports PDF and Word documents
- Streaming output (word by word like ChatGPT)
- FastAPI backend + Streamlit test UI + React frontend

---

## 📁 Project Structure

```
quizai/
├── backend/
│   ├── main.py          ← FastAPI server (start this)
│   ├── model.py         ← AI model loading & inference
│   ├── config.py        ← Change model here ← IMPORTANT
│   ├── extractor.py     ← PDF + Word text extraction
│   ├── quiz_parser.py   ← Prompt builder + JSON parser
│   └── requirements.txt
├── streamlit_app.py     ← Testing UI (run this to test)
├── react_ui/            ← React frontend
└── README.md
```

---

## 🚀 Quick Start

### Step 1 — Install Python dependencies
```bash
cd backend
pip install -r requirements.txt
```

**For GPU support (NVIDIA):**
```bash
pip install torch --index-url https://download.pytorch.org/whl/cu121
pip install bitsandbytes   # optional: enables 4-bit quantization (saves VRAM)
```

### Step 2 — Choose your model (config.py)
Open `backend/config.py` and set `MODEL_NAME`:

| Model | Size | Best For |
|---|---|---|
| `Qwen/Qwen2.5-0.5B-Instruct` | ~500 MB | Low-RAM servers, fast |
| `Qwen/Qwen2.5-1.5B-Instruct` | ~1 GB | **Default, balanced** |
| `Qwen/Qwen2.5-3B-Instruct` | ~2 GB | Better quality |
| `Qwen/Qwen2.5-7B-Instruct` | ~4.5 GB | Best quality (needs 8GB+ RAM) |
| `microsoft/Phi-3-mini-4k-instruct` | ~2.3 GB | Great at structured output |

All models are **free** from Hugging Face and download automatically on first run.

Or set via environment variable:
```bash
export QUIZ_MODEL="Qwen/Qwen2.5-3B-Instruct"
```

### Step 3 — Start the backend
```bash
cd backend
python main.py
```

Output you'll see:
```
🚀 Loading AI model on startup (one-time only)...
   Model: Qwen/Qwen2.5-1.5B-Instruct
   Device: CPU
   Loading tokenizer...
   Loading model weights (first run downloads from HuggingFace)...
✅ Model loaded successfully on CPU
INFO: Uvicorn running on http://0.0.0.0:8000
```

**First run downloads the model** (~500MB–4.5GB depending on model).
Subsequent startups load from cache (fast).

### Step 4 — Test with Streamlit UI
In a new terminal:
```bash
# From the quizai/ root folder
streamlit run streamlit_app.py
```
Opens at: http://localhost:8501

---

## 🌐 API Endpoints

| Method | Endpoint | Description |
|---|---|---|
| GET | `/` | Server info + model status |
| GET | `/health` | Health check |
| POST | `/extract-text` | Extract text from PDF/Word |
| POST | `/generate-quiz` | Generate quiz (blocking) |
| POST | `/generate-quiz-stream` | Generate quiz (streaming SSE) |

**Interactive docs:** http://localhost:8000/docs

---

## ⚛️ React Frontend Integration

```javascript
// Upload file and stream quiz generation
const formData = new FormData();
formData.append("file", file);
formData.append("num_questions", 5);
formData.append("question_type", "Multiple Choice");
formData.append("difficulty", "Medium");

const response = await fetch("http://YOUR_SERVER:8000/generate-quiz-stream", {
  method: "POST",
  body: formData,
});

const reader = response.body.getReader();
const decoder = new TextDecoder();

while (true) {
  const { done, value } = await reader.read();
  if (done) break;
  
  const chunk = decoder.decode(value);
  for (const line of chunk.split("\n")) {
    if (!line.startsWith("data: ")) continue;
    const event = JSON.parse(line.slice(6));
    
    if (event.type === "token") {
      // Append token to UI — word by word effect
      setStreamText(prev => prev + event.token);
    } else if (event.type === "done") {
      // Final parsed quiz object
      setQuiz(event.quiz);
    } else if (event.type === "error") {
      console.error(event.message);
    }
  }
}
```

### Quiz Object Structure
```json
{
  "title": "Introduction to Machine Learning",
  "questions": [
    {
      "id": 1,
      "type": "mcq",
      "question": "What is supervised learning?",
      "options": ["Option A", "Option B", "Option C", "Option D"],
      "answer": "A",
      "explanation": "Because..."
    },
    {
      "id": 2,
      "type": "tf",
      "question": "Neural networks are always better than decision trees.",
      "options": ["True", "False"],
      "answer": "False",
      "explanation": "It depends on the problem..."
    },
    {
      "id": 3,
      "type": "short",
      "question": "What does GPU stand for?",
      "options": [],
      "answer": "Graphics Processing Unit",
      "explanation": "GPU = Graphics Processing Unit..."
    }
  ]
}
```

---

## 🖥️ Deployment on a Server

### Using systemd (Linux VPS)
```bash
# /etc/systemd/system/quizai.service
[Unit]
Description=QuizAI Backend
After=network.target

[Service]
User=ubuntu
WorkingDirectory=/home/ubuntu/quizai/backend
ExecStart=/usr/bin/python3 main.py
Restart=always
Environment=QUIZ_MODEL=Qwen/Qwen2.5-1.5B-Instruct

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl enable quizai
sudo systemctl start quizai
```

### Using Docker
```dockerfile
FROM python:3.11-slim
WORKDIR /app
COPY backend/requirements.txt .
RUN pip install -r requirements.txt
COPY backend/ .
EXPOSE 8000
CMD ["python", "main.py"]
```

### Nginx reverse proxy (for HTTPS)
```nginx
location /api/ {
    proxy_pass http://localhost:8000/;
    proxy_set_header X-Real-IP $remote_addr;
    # Important for SSE streaming:
    proxy_buffering off;
    proxy_cache off;
    proxy_set_header Connection '';
    proxy_http_version 1.1;
    chunked_transfer_encoding on;
}
```

---

## 🔧 Troubleshooting

**Model takes too long on CPU?**
→ Use a smaller model: `Qwen/Qwen2.5-0.5B-Instruct`
→ Or get a GPU server (even a $10/mo GPU VPS helps a lot)

**Out of memory?**
→ Switch to a smaller model
→ Enable 4-bit quantization: set `USE_4BIT=true` (GPU only)

**"Cannot connect to API"?**
→ Make sure `python main.py` is running
→ Check firewall — port 8000 must be open

**Model download fails?**
→ Check internet connection
→ Try: `huggingface-cli login` if model is gated
→ All recommended models are ungated (no login needed)
